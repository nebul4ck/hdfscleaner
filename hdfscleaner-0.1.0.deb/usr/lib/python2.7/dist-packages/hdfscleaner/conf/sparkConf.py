# -*- encoding: utf-8 -*-

""" Spark Settings """

namenode_ip = 'hdfsnamenode01'
namenode_port = '50070'

file_user = 'spark'

directories = ['/spark/checkpoints/driver-loader']